package hello.library.member;

public enum Grade {
    BASIC,
    VIP
}
